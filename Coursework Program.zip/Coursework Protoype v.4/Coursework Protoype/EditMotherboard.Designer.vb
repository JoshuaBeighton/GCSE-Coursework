﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class EditMotherboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txt_price = New System.Windows.Forms.TextBox()
        Me.txt_m2 = New System.Windows.Forms.TextBox()
        Me.txt_SATA = New System.Windows.Forms.TextBox()
        Me.txt_socket = New System.Windows.Forms.TextBox()
        Me.txt_ram = New System.Windows.Forms.TextBox()
        Me.txt_manufacturer = New System.Windows.Forms.TextBox()
        Me.txt_name = New System.Windows.Forms.TextBox()
        Me.btn_back = New System.Windows.Forms.Button()
        Me.btn_edit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(12, 243)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(49, 25)
        Me.Label8.TabIndex = 29
        Me.Label8.Text = "Price"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(12, 206)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(86, 25)
        Me.Label6.TabIndex = 30
        Me.Label6.Text = "M.2 Slots"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(12, 169)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(98, 25)
        Me.Label5.TabIndex = 31
        Me.Label5.Text = "SATA Ports"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(12, 132)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(65, 25)
        Me.Label4.TabIndex = 32
        Me.Label4.Text = "Socket"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 95)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(95, 25)
        Me.Label3.TabIndex = 33
        Me.Label3.Text = "RAM Slots"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 58)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(117, 25)
        Me.Label2.TabIndex = 34
        Me.Label2.Text = "Manufacturer"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 21)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(59, 25)
        Me.Label1.TabIndex = 35
        Me.Label1.Text = "Name"
        '
        'txt_price
        '
        Me.txt_price.Location = New System.Drawing.Point(147, 240)
        Me.txt_price.Name = "txt_price"
        Me.txt_price.Size = New System.Drawing.Size(150, 31)
        Me.txt_price.TabIndex = 6
        '
        'txt_m2
        '
        Me.txt_m2.Location = New System.Drawing.Point(147, 203)
        Me.txt_m2.Name = "txt_m2"
        Me.txt_m2.Size = New System.Drawing.Size(150, 31)
        Me.txt_m2.TabIndex = 5
        '
        'txt_SATA
        '
        Me.txt_SATA.Location = New System.Drawing.Point(147, 166)
        Me.txt_SATA.Name = "txt_SATA"
        Me.txt_SATA.Size = New System.Drawing.Size(150, 31)
        Me.txt_SATA.TabIndex = 4
        '
        'txt_socket
        '
        Me.txt_socket.Location = New System.Drawing.Point(147, 129)
        Me.txt_socket.Name = "txt_socket"
        Me.txt_socket.Size = New System.Drawing.Size(150, 31)
        Me.txt_socket.TabIndex = 3
        '
        'txt_ram
        '
        Me.txt_ram.Location = New System.Drawing.Point(147, 92)
        Me.txt_ram.Name = "txt_ram"
        Me.txt_ram.Size = New System.Drawing.Size(150, 31)
        Me.txt_ram.TabIndex = 2
        '
        'txt_manufacturer
        '
        Me.txt_manufacturer.Location = New System.Drawing.Point(147, 55)
        Me.txt_manufacturer.Name = "txt_manufacturer"
        Me.txt_manufacturer.Size = New System.Drawing.Size(150, 31)
        Me.txt_manufacturer.TabIndex = 1
        '
        'txt_name
        '
        Me.txt_name.Location = New System.Drawing.Point(147, 18)
        Me.txt_name.Name = "txt_name"
        Me.txt_name.Size = New System.Drawing.Size(150, 31)
        Me.txt_name.TabIndex = 0
        '
        'btn_back
        '
        Me.btn_back.Location = New System.Drawing.Point(163, 277)
        Me.btn_back.Name = "btn_back"
        Me.btn_back.Size = New System.Drawing.Size(134, 80)
        Me.btn_back.TabIndex = 8
        Me.btn_back.Text = "Go Back"
        Me.btn_back.UseVisualStyleBackColor = True
        '
        'btn_edit
        '
        Me.btn_edit.Location = New System.Drawing.Point(12, 277)
        Me.btn_edit.Name = "btn_edit"
        Me.btn_edit.Size = New System.Drawing.Size(131, 80)
        Me.btn_edit.TabIndex = 7
        Me.btn_edit.Text = "Edit"
        Me.btn_edit.UseVisualStyleBackColor = True
        '
        'EditMotherboard
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(305, 366)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txt_price)
        Me.Controls.Add(Me.txt_m2)
        Me.Controls.Add(Me.txt_SATA)
        Me.Controls.Add(Me.txt_socket)
        Me.Controls.Add(Me.txt_ram)
        Me.Controls.Add(Me.txt_manufacturer)
        Me.Controls.Add(Me.txt_name)
        Me.Controls.Add(Me.btn_back)
        Me.Controls.Add(Me.btn_edit)
        Me.Name = "EditMotherboard"
        Me.Text = "Edit Motherboard"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label8 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents txt_price As TextBox
    Friend WithEvents txt_m2 As TextBox
    Friend WithEvents txt_SATA As TextBox
    Friend WithEvents txt_socket As TextBox
    Friend WithEvents txt_ram As TextBox
    Friend WithEvents txt_manufacturer As TextBox
    Friend WithEvents txt_name As TextBox
    Friend WithEvents btn_back As Button
    Friend WithEvents btn_edit As Button
End Class
