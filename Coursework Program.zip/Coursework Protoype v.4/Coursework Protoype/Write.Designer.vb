﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Write
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txt_CPU = New System.Windows.Forms.TextBox()
        Me.txt_GPU = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txt_PSU = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txt_RAM = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txt_motherboard = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txt_Case = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btn_AddStorage = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.lst_sto = New System.Windows.Forms.ListBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txt_cust = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.date_due = New System.Windows.Forms.DateTimePicker()
        Me.btn_AddOrder = New System.Windows.Forms.Button()
        Me.btn_navi = New System.Windows.Forms.Button()
        Me.btn_cpu = New System.Windows.Forms.Button()
        Me.btn_RAM = New System.Windows.Forms.Button()
        Me.btn_Case = New System.Windows.Forms.Button()
        Me.btn_GPU = New System.Windows.Forms.Button()
        Me.btn_PSU = New System.Windows.Forms.Button()
        Me.btn_Moba = New System.Windows.Forms.Button()
        Me.btn_cust = New System.Windows.Forms.Button()
        Me.lbl_Cust = New System.Windows.Forms.LinkLabel()
        Me.lbl_clearSto = New System.Windows.Forms.LinkLabel()
        Me.lbl_motherboard = New System.Windows.Forms.LinkLabel()
        Me.lbl_psu = New System.Windows.Forms.LinkLabel()
        Me.lbl_case = New System.Windows.Forms.LinkLabel()
        Me.lbl_ram = New System.Windows.Forms.LinkLabel()
        Me.lbl_CPU = New System.Windows.Forms.LinkLabel()
        Me.lbl_gpu = New System.Windows.Forms.LinkLabel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.txt_price = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(17, 42)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(49, 25)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "CPU:"
        '
        'txt_CPU
        '
        Me.txt_CPU.Location = New System.Drawing.Point(114, 37)
        Me.txt_CPU.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txt_CPU.Name = "txt_CPU"
        Me.txt_CPU.Size = New System.Drawing.Size(141, 31)
        Me.txt_CPU.TabIndex = 0
        Me.txt_CPU.TabStop = False
        Me.txt_CPU.Visible = False
        '
        'txt_GPU
        '
        Me.txt_GPU.Location = New System.Drawing.Point(481, 37)
        Me.txt_GPU.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txt_GPU.Name = "txt_GPU"
        Me.txt_GPU.Size = New System.Drawing.Size(141, 31)
        Me.txt_GPU.TabIndex = 1
        Me.txt_GPU.TabStop = False
        Me.txt_GPU.Visible = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(353, 42)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(50, 25)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "GPU:"
        '
        'txt_PSU
        '
        Me.txt_PSU.Location = New System.Drawing.Point(481, 100)
        Me.txt_PSU.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txt_PSU.Name = "txt_PSU"
        Me.txt_PSU.Size = New System.Drawing.Size(141, 31)
        Me.txt_PSU.TabIndex = 3
        Me.txt_PSU.TabStop = False
        Me.txt_PSU.Visible = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(353, 105)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(48, 25)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "PSU:"
        '
        'txt_RAM
        '
        Me.txt_RAM.Location = New System.Drawing.Point(114, 100)
        Me.txt_RAM.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txt_RAM.Name = "txt_RAM"
        Me.txt_RAM.Size = New System.Drawing.Size(141, 31)
        Me.txt_RAM.TabIndex = 2
        Me.txt_RAM.TabStop = False
        Me.txt_RAM.Visible = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(17, 105)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(55, 25)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "RAM:"
        '
        'txt_motherboard
        '
        Me.txt_motherboard.Location = New System.Drawing.Point(481, 163)
        Me.txt_motherboard.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txt_motherboard.Name = "txt_motherboard"
        Me.txt_motherboard.Size = New System.Drawing.Size(141, 31)
        Me.txt_motherboard.TabIndex = 5
        Me.txt_motherboard.TabStop = False
        Me.txt_motherboard.Visible = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(353, 168)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(122, 25)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Motherboard:"
        '
        'txt_Case
        '
        Me.txt_Case.Location = New System.Drawing.Point(114, 163)
        Me.txt_Case.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txt_Case.Name = "txt_Case"
        Me.txt_Case.Size = New System.Drawing.Size(141, 31)
        Me.txt_Case.TabIndex = 4
        Me.txt_Case.TabStop = False
        Me.txt_Case.Visible = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(17, 168)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(53, 25)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "Case:"
        '
        'btn_AddStorage
        '
        Me.btn_AddStorage.Location = New System.Drawing.Point(112, 247)
        Me.btn_AddStorage.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btn_AddStorage.Name = "btn_AddStorage"
        Me.btn_AddStorage.Size = New System.Drawing.Size(143, 38)
        Me.btn_AddStorage.TabIndex = 6
        Me.btn_AddStorage.Text = "Add Storage"
        Me.btn_AddStorage.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Label7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label7.Location = New System.Drawing.Point(17, 254)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(77, 25)
        Me.Label7.TabIndex = 8
        Me.Label7.Text = "Storage:"
        '
        'lst_sto
        '
        Me.lst_sto.FormattingEnabled = True
        Me.lst_sto.ItemHeight = 25
        Me.lst_sto.Location = New System.Drawing.Point(359, 247)
        Me.lst_sto.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.lst_sto.Name = "lst_sto"
        Me.lst_sto.Size = New System.Drawing.Size(264, 79)
        Me.lst_sto.TabIndex = 13
        Me.lst_sto.TabStop = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(17, 383)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(93, 25)
        Me.Label8.TabIndex = 8
        Me.Label8.Text = "Customer:"
        '
        'txt_cust
        '
        Me.txt_cust.Location = New System.Drawing.Point(114, 378)
        Me.txt_cust.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txt_cust.Name = "txt_cust"
        Me.txt_cust.Size = New System.Drawing.Size(141, 31)
        Me.txt_cust.TabIndex = 7
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(286, 383)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(48, 25)
        Me.Label9.TabIndex = 10
        Me.Label9.Text = "Due:"
        '
        'date_due
        '
        Me.date_due.Location = New System.Drawing.Point(339, 378)
        Me.date_due.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.date_due.Name = "date_due"
        Me.date_due.Size = New System.Drawing.Size(284, 31)
        Me.date_due.TabIndex = 8
        '
        'btn_AddOrder
        '
        Me.btn_AddOrder.Location = New System.Drawing.Point(17, 445)
        Me.btn_AddOrder.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btn_AddOrder.Name = "btn_AddOrder"
        Me.btn_AddOrder.Size = New System.Drawing.Size(313, 123)
        Me.btn_AddOrder.TabIndex = 9
        Me.btn_AddOrder.Text = "Add Order"
        Me.btn_AddOrder.UseVisualStyleBackColor = True
        '
        'btn_navi
        '
        Me.btn_navi.Location = New System.Drawing.Point(339, 445)
        Me.btn_navi.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btn_navi.Name = "btn_navi"
        Me.btn_navi.Size = New System.Drawing.Size(286, 123)
        Me.btn_navi.TabIndex = 10
        Me.btn_navi.Text = "Go Back To Navigation"
        Me.btn_navi.UseVisualStyleBackColor = True
        '
        'btn_cpu
        '
        Me.btn_cpu.Location = New System.Drawing.Point(114, 37)
        Me.btn_cpu.Name = "btn_cpu"
        Me.btn_cpu.Size = New System.Drawing.Size(141, 31)
        Me.btn_cpu.TabIndex = 0
        Me.btn_cpu.Text = "Select"
        Me.btn_cpu.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_cpu.UseVisualStyleBackColor = True
        '
        'btn_RAM
        '
        Me.btn_RAM.Location = New System.Drawing.Point(114, 99)
        Me.btn_RAM.Name = "btn_RAM"
        Me.btn_RAM.Size = New System.Drawing.Size(141, 31)
        Me.btn_RAM.TabIndex = 2
        Me.btn_RAM.Text = "Select"
        Me.btn_RAM.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_RAM.UseVisualStyleBackColor = True
        '
        'btn_Case
        '
        Me.btn_Case.Location = New System.Drawing.Point(114, 162)
        Me.btn_Case.Name = "btn_Case"
        Me.btn_Case.Size = New System.Drawing.Size(141, 31)
        Me.btn_Case.TabIndex = 4
        Me.btn_Case.Text = "Select"
        Me.btn_Case.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_Case.UseVisualStyleBackColor = True
        '
        'btn_GPU
        '
        Me.btn_GPU.Location = New System.Drawing.Point(481, 36)
        Me.btn_GPU.Name = "btn_GPU"
        Me.btn_GPU.Size = New System.Drawing.Size(141, 31)
        Me.btn_GPU.TabIndex = 1
        Me.btn_GPU.Text = "Select"
        Me.btn_GPU.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_GPU.UseVisualStyleBackColor = True
        '
        'btn_PSU
        '
        Me.btn_PSU.Location = New System.Drawing.Point(481, 101)
        Me.btn_PSU.Name = "btn_PSU"
        Me.btn_PSU.Size = New System.Drawing.Size(141, 31)
        Me.btn_PSU.TabIndex = 3
        Me.btn_PSU.Text = "Select"
        Me.btn_PSU.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_PSU.UseVisualStyleBackColor = True
        '
        'btn_Moba
        '
        Me.btn_Moba.Location = New System.Drawing.Point(481, 162)
        Me.btn_Moba.Name = "btn_Moba"
        Me.btn_Moba.Size = New System.Drawing.Size(141, 31)
        Me.btn_Moba.TabIndex = 5
        Me.btn_Moba.Text = "Select"
        Me.btn_Moba.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btn_Moba.UseVisualStyleBackColor = True
        '
        'btn_cust
        '
        Me.btn_cust.Location = New System.Drawing.Point(114, 378)
        Me.btn_cust.Name = "btn_cust"
        Me.btn_cust.Size = New System.Drawing.Size(141, 30)
        Me.btn_cust.TabIndex = 14
        Me.btn_cust.Text = "Select"
        Me.btn_cust.UseVisualStyleBackColor = True
        '
        'lbl_Cust
        '
        Me.lbl_Cust.AutoSize = True
        Me.lbl_Cust.Location = New System.Drawing.Point(213, 411)
        Me.lbl_Cust.Name = "lbl_Cust"
        Me.lbl_Cust.Size = New System.Drawing.Size(42, 25)
        Me.lbl_Cust.TabIndex = 15
        Me.lbl_Cust.TabStop = True
        Me.lbl_Cust.Text = "Edit"
        Me.lbl_Cust.Visible = False
        '
        'lbl_clearSto
        '
        Me.lbl_clearSto.AutoSize = True
        Me.lbl_clearSto.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.lbl_clearSto.Location = New System.Drawing.Point(571, 328)
        Me.lbl_clearSto.Name = "lbl_clearSto"
        Me.lbl_clearSto.Size = New System.Drawing.Size(51, 25)
        Me.lbl_clearSto.TabIndex = 16
        Me.lbl_clearSto.TabStop = True
        Me.lbl_clearSto.Text = "Clear"
        '
        'lbl_motherboard
        '
        Me.lbl_motherboard.AutoSize = True
        Me.lbl_motherboard.Location = New System.Drawing.Point(580, 196)
        Me.lbl_motherboard.Name = "lbl_motherboard"
        Me.lbl_motherboard.Size = New System.Drawing.Size(42, 25)
        Me.lbl_motherboard.TabIndex = 17
        Me.lbl_motherboard.TabStop = True
        Me.lbl_motherboard.Text = "Edit"
        Me.lbl_motherboard.Visible = False
        '
        'lbl_psu
        '
        Me.lbl_psu.AutoSize = True
        Me.lbl_psu.Location = New System.Drawing.Point(580, 130)
        Me.lbl_psu.Name = "lbl_psu"
        Me.lbl_psu.Size = New System.Drawing.Size(42, 25)
        Me.lbl_psu.TabIndex = 18
        Me.lbl_psu.TabStop = True
        Me.lbl_psu.Text = "Edit"
        Me.lbl_psu.Visible = False
        '
        'lbl_case
        '
        Me.lbl_case.AutoSize = True
        Me.lbl_case.Location = New System.Drawing.Point(215, 196)
        Me.lbl_case.Name = "lbl_case"
        Me.lbl_case.Size = New System.Drawing.Size(42, 25)
        Me.lbl_case.TabIndex = 19
        Me.lbl_case.TabStop = True
        Me.lbl_case.Text = "Edit"
        Me.lbl_case.Visible = False
        '
        'lbl_ram
        '
        Me.lbl_ram.AutoSize = True
        Me.lbl_ram.Location = New System.Drawing.Point(215, 133)
        Me.lbl_ram.Name = "lbl_ram"
        Me.lbl_ram.Size = New System.Drawing.Size(42, 25)
        Me.lbl_ram.TabIndex = 20
        Me.lbl_ram.TabStop = True
        Me.lbl_ram.Text = "Edit"
        Me.lbl_ram.Visible = False
        '
        'lbl_CPU
        '
        Me.lbl_CPU.AutoSize = True
        Me.lbl_CPU.Location = New System.Drawing.Point(213, 70)
        Me.lbl_CPU.Name = "lbl_CPU"
        Me.lbl_CPU.Size = New System.Drawing.Size(42, 25)
        Me.lbl_CPU.TabIndex = 21
        Me.lbl_CPU.TabStop = True
        Me.lbl_CPU.Text = "Edit"
        Me.lbl_CPU.Visible = False
        '
        'lbl_gpu
        '
        Me.lbl_gpu.AutoSize = True
        Me.lbl_gpu.Location = New System.Drawing.Point(580, 67)
        Me.lbl_gpu.Name = "lbl_gpu"
        Me.lbl_gpu.Size = New System.Drawing.Size(42, 25)
        Me.lbl_gpu.TabIndex = 22
        Me.lbl_gpu.TabStop = True
        Me.lbl_gpu.Text = "Edit"
        Me.lbl_gpu.Visible = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.PictureBox1.Location = New System.Drawing.Point(17, 224)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(609, 129)
        Me.PictureBox1.TabIndex = 23
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.SystemColors.Control
        Me.PictureBox2.Location = New System.Drawing.Point(17, 293)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(317, 60)
        Me.PictureBox2.TabIndex = 23
        Me.PictureBox2.TabStop = False
        '
        'txt_price
        '
        Me.txt_price.Location = New System.Drawing.Point(114, 312)
        Me.txt_price.Name = "txt_price"
        Me.txt_price.Size = New System.Drawing.Size(141, 31)
        Me.txt_price.TabIndex = 24
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(21, 312)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(49, 25)
        Me.Label10.TabIndex = 25
        Me.Label10.Text = "Price"
        '
        'Write
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(641, 588)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.txt_price)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.lbl_Cust)
        Me.Controls.Add(Me.lbl_clearSto)
        Me.Controls.Add(Me.lbl_motherboard)
        Me.Controls.Add(Me.lbl_psu)
        Me.Controls.Add(Me.lbl_case)
        Me.Controls.Add(Me.lbl_ram)
        Me.Controls.Add(Me.lbl_CPU)
        Me.Controls.Add(Me.lbl_gpu)
        Me.Controls.Add(Me.btn_cust)
        Me.Controls.Add(Me.btn_Moba)
        Me.Controls.Add(Me.btn_PSU)
        Me.Controls.Add(Me.btn_GPU)
        Me.Controls.Add(Me.btn_Case)
        Me.Controls.Add(Me.btn_RAM)
        Me.Controls.Add(Me.btn_cpu)
        Me.Controls.Add(Me.btn_navi)
        Me.Controls.Add(Me.btn_AddOrder)
        Me.Controls.Add(Me.date_due)
        Me.Controls.Add(Me.lst_sto)
        Me.Controls.Add(Me.btn_AddStorage)
        Me.Controls.Add(Me.txt_motherboard)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txt_cust)
        Me.Controls.Add(Me.txt_Case)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txt_PSU)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txt_RAM)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txt_GPU)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txt_CPU)
        Me.Controls.Add(Me.Label1)
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "Write"
        Me.Text = "Add Order"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents txt_CPU As TextBox
    Friend WithEvents txt_GPU As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txt_PSU As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txt_RAM As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txt_motherboard As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents txt_Case As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents btn_AddStorage As Button
    Friend WithEvents Label7 As Label
    Friend WithEvents lst_sto As ListBox
    Friend WithEvents Label8 As Label
    Friend WithEvents txt_cust As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents date_due As DateTimePicker
    Friend WithEvents btn_AddOrder As Button
    Friend WithEvents btn_navi As Button
    Friend WithEvents btn_cpu As Button
    Friend WithEvents btn_RAM As Button
    Friend WithEvents btn_Case As Button
    Friend WithEvents btn_GPU As Button
    Friend WithEvents btn_PSU As Button
    Friend WithEvents btn_Moba As Button
    Friend WithEvents btn_cust As Button
    Friend WithEvents lbl_Cust As LinkLabel
    Friend WithEvents lbl_clearSto As LinkLabel
    Friend WithEvents lbl_motherboard As LinkLabel
    Friend WithEvents lbl_psu As LinkLabel
    Friend WithEvents lbl_case As LinkLabel
    Friend WithEvents lbl_ram As LinkLabel
    Friend WithEvents lbl_CPU As LinkLabel
    Friend WithEvents lbl_gpu As LinkLabel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents txt_price As TextBox
    Friend WithEvents Label10 As Label
End Class
